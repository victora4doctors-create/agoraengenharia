import { ArrowDown, Sparkles } from "lucide-react";
import { motion } from "framer-motion";
import { Reveal } from "./Reveal";

export function Savings() {
  return (
    <section className="relative overflow-hidden bg-gradient-dark py-24 text-dark-foreground sm:py-32">
      <div className="absolute inset-0 opacity-30" aria-hidden>
        <div className="absolute -top-40 left-1/2 h-96 w-96 -translate-x-1/2 rounded-full bg-primary/40 blur-3xl" />
        <div className="absolute bottom-0 right-0 h-96 w-96 rounded-full bg-eco/30 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <Reveal className="text-center">
          <span className="text-xs font-semibold uppercase tracking-widest text-primary">
            Economia Real
          </span>
          <h2 className="mt-3 text-4xl font-bold sm:text-5xl">
            Veja como sua conta pode diminuir
          </h2>
        </Reveal>

        <div className="mt-14 grid gap-6 md:grid-cols-[1fr_auto_1fr] md:items-center">
          <Reveal>
            <div className="rounded-3xl border border-dark-foreground/10 bg-dark-foreground/5 p-8 backdrop-blur-sm">
              <div className="text-sm uppercase tracking-wider text-dark-foreground/60">
                Conta tradicional
              </div>
              <div className="mt-3 font-display text-5xl font-bold text-dark-foreground/90 line-through decoration-destructive/70 decoration-4">
                R$ 1.250
              </div>
              <div className="mt-2 text-sm text-dark-foreground/60">por mês</div>
            </div>
          </Reveal>

          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ repeat: Infinity, duration: 1.8, ease: "easeInOut" }}
            className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary shadow-glow md:rotate-[-90deg]"
          >
            <ArrowDown className="h-6 w-6 text-dark" strokeWidth={2.5} />
          </motion.div>

          <Reveal delay={0.2}>
            <div className="rounded-3xl border border-primary/40 bg-primary/10 p-8 shadow-glow backdrop-blur-sm">
              <div className="text-sm uppercase tracking-wider text-primary">
                Com energia por assinatura
              </div>
              <div className="mt-3 font-display text-5xl font-bold text-dark-foreground">
                R$ 1.062
              </div>
              <div className="mt-2 text-sm text-dark-foreground/70">por mês</div>
            </div>
          </Reveal>
        </div>

        <Reveal className="mt-12 text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-gradient-solar px-6 py-3 text-base font-bold text-dark shadow-glow">
            <Sparkles className="h-4 w-4" /> Você economiza R$ 188/mês
          </div>
          <p className="mx-auto mt-6 max-w-2xl text-dark-foreground/75">
            Através da compensação de créditos de energia, você reduz seus custos sem
            precisar investir em instalação.
          </p>
          <a
            href="#contato"
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-primary px-7 py-4 text-base font-semibold text-primary-foreground shadow-glow transition-transform hover:scale-105"
          >
            Quero simular minha economia
          </a>
        </Reveal>
      </div>
    </section>
  );
}
