import { motion } from "framer-motion";
import { ArrowRight, Sparkles, Users, TrendingDown, Zap } from "lucide-react";
import heroImage from "@/assets/hero-solar.jpg";

export function Hero() {
  return (
    <section id="top" className="relative min-h-screen overflow-hidden">
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Usina de energia solar vista de drone ao pôr do sol"
          className="h-full w-full object-cover"
          width={1920}
          height={1280}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-dark/50 via-dark/55 to-dark/85" />
      </div>

      <div className="relative z-10 mx-auto flex min-h-screen max-w-7xl flex-col justify-center px-4 pb-20 pt-32 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-3xl"
        >
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-primary backdrop-blur-sm">
            <Sparkles className="h-3.5 w-3.5" /> Energia Solar Inteligente
          </span>
          <h1 className="mt-6 font-display text-5xl font-bold leading-[1.05] text-dark-foreground sm:text-6xl lg:text-7xl">
            Economia inteligente com{" "}
            <span className="text-gradient-solar">energia solar</span>
          </h1>
          <p className="mt-6 max-w-2xl text-lg text-dark-foreground/80 sm:text-xl">
            Instale sua própria usina solar ou economize todos os meses com
            energia por assinatura — sem obras e sem investimento inicial.
          </p>

          <div className="mt-10 flex flex-wrap gap-4">
            <a
              href="#solucoes"
              className="group inline-flex items-center gap-2 rounded-full bg-primary px-7 py-4 text-base font-semibold text-primary-foreground shadow-glow transition-transform hover:scale-[1.03]"
            >
              Quero instalar energia solar
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
            <a
              href="#solucoes"
              className="inline-flex items-center gap-2 rounded-full border border-dark-foreground/30 bg-dark-foreground/5 px-7 py-4 text-base font-semibold text-dark-foreground backdrop-blur-sm transition-colors hover:bg-dark-foreground/15"
            >
              Quero economizar por assinatura
            </a>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="mt-20 grid gap-px overflow-hidden rounded-2xl border border-dark-foreground/15 bg-dark-foreground/10 backdrop-blur-md sm:grid-cols-3"
        >
          {[
            { icon: Users, value: "+1.200", label: "clientes atendidos" },
            { icon: TrendingDown, value: "Até 95%", label: "economia para residências e empresas" },
            { icon: Zap, value: "100%", label: "soluções completas em energia" },
          ].map((m) => (
            <div key={m.label} className="bg-dark/70 p-6 backdrop-blur-md">
              <m.icon className="h-6 w-6 text-primary" />
              <div className="mt-3 font-display text-3xl font-bold text-dark-foreground">
                {m.value}
              </div>
              <div className="mt-1 text-sm text-dark-foreground/70">{m.label}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
