import { Star, Quote } from "lucide-react";
import { Reveal } from "./Reveal";

const items = [
  { name: "Ricardo M.", role: "Cliente residencial", text: "A redução na conta veio já nos primeiros meses. Processo simples e atendimento excelente." },
  { name: "Carla S.", role: "Empresária", text: "Conseguimos economizar sem precisar instalar placas." },
  { name: "João P.", role: "Produtor rural", text: "Equipe muito preparada e acompanhamento rápido." },
];

export function Testimonials() {
  return (
    <section className="bg-background py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-semibold uppercase tracking-widest text-eco">
            Depoimentos
          </span>
          <h2 className="mt-3 text-4xl font-bold sm:text-5xl">
            Quem já economiza com a Agora
          </h2>
        </Reveal>

        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {items.map((t, i) => (
            <Reveal key={t.name} delay={i * 0.1}>
              <figure className="flex h-full flex-col rounded-2xl border border-border bg-card p-8 shadow-soft">
                <Quote className="h-8 w-8 text-primary/40" />
                <div className="mt-4 flex gap-0.5 text-primary">
                  {Array.from({ length: 5 }).map((_, idx) => (
                    <Star key={idx} className="h-4 w-4 fill-current" />
                  ))}
                </div>
                <blockquote className="mt-4 flex-1 text-foreground/90">
                  "{t.text}"
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-3 border-t border-border pt-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-solar text-sm font-bold text-dark">
                    {t.name.charAt(0)}
                  </div>
                  <div>
                    <div className="text-sm font-semibold">{t.name}</div>
                    <div className="text-xs text-muted-foreground">{t.role}</div>
                  </div>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
