import { ImageIcon } from "lucide-react";
import { Reveal } from "./Reveal";

const projects = [
  { label: "Usina solar — Interior MG", ratio: "aspect-[4/5]" },
  { label: "Instalação residencial", ratio: "aspect-square" },
  { label: "Equipe técnica em campo", ratio: "aspect-square" },
  { label: "Vista de drone — propriedade rural", ratio: "aspect-[4/5]" },
  { label: "Cliente satisfeito", ratio: "aspect-square" },
  { label: "Usina comercial", ratio: "aspect-[4/5]" },
  { label: "Painéis em telhado industrial", ratio: "aspect-square" },
  { label: "Inspeção técnica", ratio: "aspect-[4/5]" },
];

export function Projects() {
  return (
    <section id="projetos" className="bg-muted/50 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal className="mx-auto max-w-3xl text-center">
          <span className="text-xs font-semibold uppercase tracking-widest text-primary">
            Portfólio
          </span>
          <h2 className="mt-3 text-4xl font-bold sm:text-5xl">Projetos realizados</h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Atuamos com soluções energéticas para residências, empresas e propriedades rurais,
            entregando eficiência, economia e suporte especializado.
          </p>
        </Reveal>

        <div className="mt-14 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {projects.map((p, i) => (
            <Reveal key={p.label} delay={(i % 4) * 0.05}>
              <figure className="group relative overflow-hidden rounded-2xl border border-border bg-card shadow-soft">
                <div className={`${p.ratio} flex items-center justify-center bg-gradient-to-br from-muted to-secondary`}>
                  <ImageIcon className="h-10 w-10 text-muted-foreground/40 transition-transform duration-700 group-hover:scale-125" />
                </div>
                <figcaption className="absolute inset-x-0 bottom-0 translate-y-2 bg-gradient-to-t from-dark/90 via-dark/50 to-transparent p-4 text-sm font-medium text-dark-foreground opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100">
                  {p.label}
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
