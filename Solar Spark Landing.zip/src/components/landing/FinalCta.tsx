import { MessageCircle } from "lucide-react";
import { Reveal } from "./Reveal";

export function FinalCta() {
  return (
    <section id="contato" className="relative overflow-hidden bg-dark py-24 text-dark-foreground sm:py-32">
      <div className="absolute inset-0 opacity-40" aria-hidden>
        <div className="absolute left-1/4 top-0 h-96 w-96 -translate-x-1/2 rounded-full bg-primary/40 blur-3xl" />
        <div className="absolute bottom-0 right-1/4 h-96 w-96 translate-x-1/2 rounded-full bg-sun/30 blur-3xl" />
      </div>
      <div className="relative mx-auto max-w-3xl px-4 text-center sm:px-6 lg:px-8">
        <Reveal>
          <h2 className="font-display text-4xl font-bold leading-tight sm:text-6xl">
            Descubra quanto você pode <span className="text-gradient-solar">economizar</span>
          </h2>
          <p className="mx-auto mt-6 max-w-xl text-lg text-dark-foreground/75">
            Envie sua conta de energia e receba uma análise personalizada da nossa equipe.
          </p>
          <a
            href="https://wa.me/5500000000000"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-10 inline-flex items-center gap-3 rounded-full bg-gradient-solar px-9 py-5 text-lg font-bold text-dark shadow-glow transition-transform hover:scale-105"
          >
            <MessageCircle className="h-6 w-6" /> Falar no WhatsApp
          </a>
        </Reveal>
      </div>
    </section>
  );
}
