import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, PencilRuler, Wrench, TrendingDown, FileText, PlugZap, Coins, BadgePercent } from "lucide-react";
import { Reveal } from "./Reveal";

const flows = {
  solar: [
    { icon: Search, title: "Análise", desc: "Analisamos seu consumo e necessidade energética." },
    { icon: PencilRuler, title: "Projeto", desc: "Criamos uma solução personalizada para seu imóvel." },
    { icon: Wrench, title: "Instalação", desc: "Executamos toda instalação e homologação." },
    { icon: TrendingDown, title: "Economia", desc: "Você começa a gerar sua própria energia." },
  ],
  assinatura: [
    { icon: FileText, title: "Envie sua conta", desc: "Analisamos seu perfil de consumo." },
    { icon: PlugZap, title: "Conexão", desc: "Conectamos você às nossas usinas solares." },
    { icon: Coins, title: "Créditos", desc: "A energia gerada vira créditos na sua conta." },
    { icon: BadgePercent, title: "Desconto", desc: "Você economiza todos os meses." },
  ],
};

export function HowItWorks() {
  const [tab, setTab] = useState<"solar" | "assinatura">("solar");
  const steps = flows[tab];

  return (
    <section id="como-funciona" className="bg-muted/50 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-semibold uppercase tracking-widest text-primary">
            Processo
          </span>
          <h2 className="mt-3 text-4xl font-bold sm:text-5xl">Como funciona</h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Soluções simples, seguras e inteligentes para reduzir seus custos com energia.
          </p>
        </Reveal>

        <div className="mt-10 flex justify-center">
          <div className="inline-flex rounded-full border border-border bg-card p-1.5 shadow-soft">
            {(["solar", "assinatura"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`relative rounded-full px-6 py-2.5 text-sm font-semibold capitalize transition-colors ${
                  tab === t ? "text-primary-foreground" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {tab === t && (
                  <motion.span
                    layoutId="tab-pill"
                    className="absolute inset-0 rounded-full bg-primary shadow-glow"
                    transition={{ type: "spring", duration: 0.5 }}
                  />
                )}
                <span className="relative">{t === "solar" ? "Energia Solar" : "Assinatura"}</span>
              </button>
            ))}
          </div>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.4 }}
            className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-4"
          >
            {steps.map((s, i) => (
              <div key={s.title} className="relative rounded-2xl border border-border bg-card p-7 shadow-soft">
                <div className="absolute -top-4 left-7 flex h-9 w-9 items-center justify-center rounded-full bg-gradient-solar text-sm font-bold text-dark shadow-glow">
                  {i + 1}
                </div>
                <s.icon className="h-9 w-9 text-primary" strokeWidth={1.75} />
                <h3 className="mt-5 font-display text-xl font-bold">{s.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
              </div>
            ))}
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  );
}
