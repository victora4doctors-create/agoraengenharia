import { Sun, Phone, MessageCircle, Instagram, Mail, MapPin } from "lucide-react";

const links = [
  { href: "#solucoes", label: "Soluções" },
  { href: "#como-funciona", label: "Como Funciona" },
  { href: "#projetos", label: "Projetos" },
  { href: "#faq", label: "FAQ" },
  { href: "#contato", label: "Contato" },
];

const contacts = [
  { icon: Phone, label: "(00) 0000-0000" },
  { icon: MessageCircle, label: "WhatsApp: (00) 90000-0000" },
  { icon: Instagram, label: "@agoraengenharia" },
  { icon: Mail, label: "contato@agoraengenharia.com.br" },
  { icon: MapPin, label: "Atendemos sua região" },
];

export function Footer() {
  return (
    <footer className="border-t border-border bg-muted/40 py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-3">
          <div>
            <a href="#top" className="flex items-center gap-2.5">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-solar shadow-glow">
                <Sun className="h-5 w-5 text-dark" strokeWidth={2.5} />
              </span>
              <span className="font-display text-lg font-bold">
                Agora<span className="text-primary"> Engenharia</span>
              </span>
            </a>
            <p className="mt-4 max-w-xs text-sm text-muted-foreground">
              Soluções inteligentes em energia solar para residências, empresas e propriedades rurais.
            </p>
          </div>

          <div>
            <h3 className="font-display text-sm font-bold uppercase tracking-wider">
              Navegação
            </h3>
            <ul className="mt-4 space-y-2.5">
              {links.map((l) => (
                <li key={l.href}>
                  <a
                    href={l.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-primary"
                  >
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-display text-sm font-bold uppercase tracking-wider">
              Contato
            </h3>
            <ul className="mt-4 space-y-2.5">
              {contacts.map((c) => (
                <li key={c.label} className="flex items-start gap-2.5 text-sm text-muted-foreground">
                  <c.icon className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                  <span>{c.label}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-border pt-8 text-xs text-muted-foreground sm:flex-row">
          <span>© 2026 Agora Engenharia. Todos os direitos reservados.</span>
          <span>Energia solar inteligente.</span>
        </div>
      </div>
    </footer>
  );
}
