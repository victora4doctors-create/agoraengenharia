import { Cog, Handshake, PiggyBank, Leaf, Package, ShieldCheck } from "lucide-react";
import { Reveal } from "./Reveal";

const items = [
  { icon: Cog, title: "Engenharia especializada", desc: "Equipe técnica preparada para soluções eficientes." },
  { icon: Handshake, title: "Atendimento consultivo", desc: "Suporte próximo e personalizado." },
  { icon: PiggyBank, title: "Economia inteligente", desc: "Redução de custos com soluções modernas." },
  { icon: Leaf, title: "Energia sustentável", desc: "Mais economia com responsabilidade ambiental." },
  { icon: Package, title: "Soluções completas", desc: "Projetos para residências, empresas e agronegócio." },
  { icon: ShieldCheck, title: "Segurança e confiabilidade", desc: "Processos homologados e acompanhamento técnico." },
];

export function Benefits() {
  return (
    <section className="bg-background py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-semibold uppercase tracking-widest text-eco">
            Diferenciais
          </span>
          <h2 className="mt-3 text-4xl font-bold sm:text-5xl">
            Por que escolher a <span className="text-gradient-solar">Agora Engenharia</span>?
          </h2>
        </Reveal>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((it, i) => (
            <Reveal key={it.title} delay={i * 0.06}>
              <div className="group h-full rounded-2xl border border-border bg-card p-8 transition-all hover:-translate-y-1 hover:border-primary/40 hover:shadow-glow">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-solar shadow-glow transition-transform group-hover:rotate-6">
                  <it.icon className="h-7 w-7 text-dark" strokeWidth={2} />
                </div>
                <h3 className="mt-6 font-display text-xl font-bold">{it.title}</h3>
                <p className="mt-2 text-muted-foreground">{it.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
