import { CheckCircle2 } from "lucide-react";
import { Reveal } from "./Reveal";
import aboutImg from "@/assets/about-team.jpg";

export function About() {
  return (
    <section className="bg-muted/50 py-24 sm:py-32">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
        <Reveal>
          <div className="relative">
            <div className="absolute -inset-4 rounded-3xl bg-gradient-solar opacity-30 blur-2xl" />
            <img
              src={aboutImg}
              alt="Equipe da Agora Engenharia em campo"
              loading="lazy"
              width={1024}
              height={900}
              className="relative aspect-[4/3] w-full rounded-3xl object-cover shadow-soft"
            />
          </div>
        </Reveal>

        <Reveal delay={0.15}>
          <span className="text-xs font-semibold uppercase tracking-widest text-primary">
            Sobre nós
          </span>
          <h2 className="mt-3 text-4xl font-bold sm:text-5xl">
            Sobre a <span className="text-gradient-solar">Agora Engenharia</span>
          </h2>
          <p className="mt-6 text-lg text-muted-foreground">
            A Agora Engenharia atua com soluções inteligentes em energia solar, oferecendo
            projetos completos, energia por assinatura e acompanhamento especializado para
            residências, empresas e propriedades rurais. Nosso objetivo é entregar economia,
            eficiência e segurança através de tecnologias energéticas modernas.
          </p>
          <ul className="mt-8 space-y-3">
            {[
              "Projetos personalizados de engenharia",
              "Acompanhamento técnico do início ao fim",
              "Soluções para todos os portes e perfis",
            ].map((b) => (
              <li key={b} className="flex items-center gap-3">
                <CheckCircle2 className="h-5 w-5 text-eco" />
                <span>{b}</span>
              </li>
            ))}
          </ul>
        </Reveal>
      </div>
    </section>
  );
}
