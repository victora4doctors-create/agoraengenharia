import { Check, ArrowRight } from "lucide-react";
import { Reveal } from "./Reveal";
import solarImg from "@/assets/solar-install.jpg";
import subImg from "@/assets/subscription.jpg";

const cards = [
  {
    img: solarImg,
    alt: "Painéis solares instalados em telhado residencial",
    title: "Energia Solar",
    desc: "Projetos completos para residências, empresas e propriedades rurais com instalação, homologação e suporte especializado.",
    bullets: ["Projeto personalizado", "Instalação completa", "Economia a longo prazo", "Valorização do imóvel"],
    cta: "Solicitar orçamento",
    accent: "primary" as const,
  },
  {
    img: subImg,
    alt: "Conta de energia e usina solar ao fundo",
    title: "Energia por Assinatura",
    desc: "Economize na conta de energia sem instalar placas solares e sem investimento inicial através de créditos gerados pelas nossas usinas.",
    bullets: ["Até 15% de desconto", "Sem instalação", "Sem obras", "Ativação simplificada"],
    cta: "Simular economia",
    accent: "eco" as const,
  },
];

export function Solutions() {
  return (
    <section id="solucoes" className="bg-background py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-semibold uppercase tracking-widest text-primary">
            Soluções
          </span>
          <h2 className="mt-3 text-4xl font-bold sm:text-5xl">
            Qual solução é ideal para você?
          </h2>
        </Reveal>

        <div className="mt-16 grid gap-8 lg:grid-cols-2">
          {cards.map((c, i) => (
            <Reveal key={c.title} delay={i * 0.1}>
              <article className="group h-full overflow-hidden rounded-3xl border border-border bg-card shadow-soft transition-all hover:shadow-glow">
                <div className="aspect-[16/10] overflow-hidden bg-muted">
                  <img
                    src={c.img}
                    alt={c.alt}
                    loading="lazy"
                    width={1024}
                    height={768}
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
                <div className="p-8 sm:p-10">
                  <h3 className="font-display text-2xl font-bold sm:text-3xl">
                    {c.title}
                  </h3>
                  <p className="mt-3 text-muted-foreground">{c.desc}</p>
                  <ul className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2">
                    {c.bullets.map((b) => (
                      <li key={b} className="flex items-center gap-2.5 text-sm">
                        <span
                          className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full ${
                            c.accent === "primary"
                              ? "bg-primary/15 text-primary"
                              : "bg-eco/15 text-eco"
                          }`}
                        >
                          <Check className="h-3.5 w-3.5" strokeWidth={3} />
                        </span>
                        {b}
                      </li>
                    ))}
                  </ul>
                  <a
                    href="#contato"
                    className={`mt-8 inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold transition-transform hover:scale-105 ${
                      c.accent === "primary"
                        ? "bg-primary text-primary-foreground shadow-glow"
                        : "bg-eco text-eco-foreground"
                    }`}
                  >
                    {c.cta} <ArrowRight className="h-4 w-4" />
                  </a>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
